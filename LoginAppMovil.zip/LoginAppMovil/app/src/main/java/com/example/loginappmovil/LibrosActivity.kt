package com.example.loginappmovil

import android.content.Intent
import android.graphics.drawable.AnimationDrawable
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.squareup.picasso.Picasso
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class LibrosActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_libros)

        val rootLayout = findViewById<LinearLayout>(R.id.rootLayoutLibros)
        val etBuscar = findViewById<EditText>(R.id.etBuscarLibro)
        val btnBuscar = findViewById<ImageButton>(R.id.btnBuscar)
        val contenedor = findViewById<LinearLayout>(R.id.contenedorLibros)

        try {
            val anim = rootLayout.background as AnimationDrawable
            anim.setEnterFadeDuration(2000)
            anim.setExitFadeDuration(4000)
            anim.start()
        } catch (e: Exception) {
            e.printStackTrace()
        }

        btnBuscar.setOnClickListener {
            val query = etBuscar.text.toString().trim()
            if (query.isNotEmpty()) {
                buscarLibros(query, contenedor)
            } else {
                Toast.makeText(this, "Ingresa un título para buscar", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun buscarLibros(query: String, contenedor: LinearLayout) {
        contenedor.removeAllViews()
        thread {
            try {
                val url = URL("https://www.googleapis.com/books/v1/volumes?q=${query.replace(" ", "+")}")
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "GET"
                conn.connect()

                val data = conn.inputStream.bufferedReader().readText()
                val json = JSONObject(data)
                val items = json.getJSONArray("items")

                runOnUiThread {
                    for (i in 0 until items.length()) {
                        val item = items.getJSONObject(i)
                        val info = item.getJSONObject("volumeInfo")

                        val titulo = info.optString("title", "Sin título")
                        val autores = info.optJSONArray("authors")?.join(", ") ?: "Autor desconocido"
                        val descripcion = info.optString("description", "Sin descripción disponible.")
                        val portada = info.optJSONObject("imageLinks")?.optString("thumbnail")

                        val vista = layoutInflater.inflate(R.layout.item_libro, contenedor, false)
                        val img = vista.findViewById<ImageView>(R.id.imgLibro)
                        val tvTitulo = vista.findViewById<TextView>(R.id.tvTitulo)
                        val tvAutor = vista.findViewById<TextView>(R.id.tvAutor)
                        val tvDescripcion = vista.findViewById<TextView>(R.id.tvDescripcion)
                        val btnAgregar = vista.findViewById<Button>(R.id.btnAgregar)

                        tvTitulo.text = titulo
                        tvAutor.text = autores
                        tvDescripcion.text = descripcion

                        if (portada != null) {
                            Picasso.get().load(portada.replace("http://", "https://"))
                                .fit()
                                .centerCrop()
                                .into(img)
                        } else {
                            img.setImageResource(android.R.drawable.ic_menu_report_image)
                        }


                        btnAgregar.setOnClickListener {
                            val intent = Intent(this, AgregarLibroActivity::class.java)
                            intent.putExtra("titulo", titulo)
                            intent.putExtra("autor", autores)
                            intent.putExtra("descripcion", descripcion)
                            intent.putExtra("portada", portada)
                            startActivity(intent)
                        }

                        contenedor.addView(vista)
                    }
                }

            } catch (e: Exception) {
                Log.e("LibrosActivity", "Error: ${e.message}")
                runOnUiThread {
                    Toast.makeText(this, "Error al buscar libros", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}
