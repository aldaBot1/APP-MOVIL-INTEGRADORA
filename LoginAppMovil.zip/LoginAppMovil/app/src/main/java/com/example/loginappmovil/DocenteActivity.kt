package com.example.loginappmovil

import android.content.Intent
import android.graphics.drawable.AnimationDrawable
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class DocenteActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_docente)

        // Inicializar Firebase
        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()

        // Fondo animado
        val rootLayout = findViewById<RelativeLayout>(R.id.rootLayoutDocente)
        try {
            val anim = rootLayout.background as AnimationDrawable
            anim.setEnterFadeDuration(2000)
            anim.setExitFadeDuration(4000)
            anim.start()
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // Referencias del layout
        val etNombre = findViewById<EditText>(R.id.etAlumnoNombre)
        val etEmail = findViewById<EditText>(R.id.etAlumnoEmail)
        val etPassword = findViewById<EditText>(R.id.etAlumnoPassword)
        val btnCrear = findViewById<Button>(R.id.btnCrearAlumno)
        val btnLogout = findViewById<Button>(R.id.btnLogoutDocente)

        // Crear alumno (usuario con rol alumno)
        btnCrear.setOnClickListener {
            val nombre = etNombre.text.toString().trim()
            val email = etEmail.text.toString().trim()
            val password = etPassword.text.toString().trim()
            val btnLibros = findViewById<Button>(R.id.btnLibros)

            btnLibros.setOnClickListener {
                startActivity(Intent(this, LibrosActivity::class.java))
            }


            if (nombre.isEmpty() || email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Completa todos los campos", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            auth.createUserWithEmailAndPassword(email, password)
                .addOnSuccessListener { result ->
                    val uid = result.user?.uid ?: return@addOnSuccessListener

                    val alumnoData = hashMapOf(
                        "uid" to uid,
                        "nombre" to nombre,
                        "email" to email,
                        "rol" to "alumno"
                    )

                    db.collection("users").document(uid)
                        .set(alumnoData)
                        .addOnSuccessListener {
                            Toast.makeText(this, "Alumno creado correctamente", Toast.LENGTH_SHORT).show()
                            etNombre.text.clear()
                            etEmail.text.clear()
                            etPassword.text.clear()
                        }
                        .addOnFailureListener {
                            Toast.makeText(this, "Error al guardar en Firestore", Toast.LENGTH_LONG).show()
                        }
                }
                .addOnFailureListener {
                    Toast.makeText(this, "Error: ${it.message}", Toast.LENGTH_LONG).show()
                }
        }

        // Cerrar sesión
        btnLogout.setOnClickListener {
            FirebaseAuth.getInstance().signOut()
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }
}
