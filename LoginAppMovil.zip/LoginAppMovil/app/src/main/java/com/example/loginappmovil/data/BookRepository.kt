package com.example.loginappmovil.data

import com.google.firebase.firestore.FirebaseFirestore

data class Book(
    val titulo: String = "",
    val autor: String = "",
    val categoria: String = "",
    val cantidadDisponible: Int = 0,
    val donadoPor: String = ""
)

class BookRepository {
    private val db = FirebaseFirestore.getInstance()

    fun agregarLibro(libro: Book, onSuccess: () -> Unit, onError: (Exception) -> Unit) {
        val docRef = db.collection("books").document()
        db.collection("books").document(docRef.id).set(libro)
            .addOnSuccessListener { onSuccess() }
            .addOnFailureListener { onError(it) }
    }

    fun actualizarStock(bookId: String, nuevaCantidad: Int) {
        db.collection("books").document(bookId)
            .update("cantidadDisponible", nuevaCantidad)
    }
}
