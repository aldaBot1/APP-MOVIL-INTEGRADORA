package com.example.loginappmovil

import android.content.Intent
import android.graphics.drawable.AnimationDrawable
import android.os.Bundle
import android.widget.*
import android.widget.RelativeLayout
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class AdminActivity : AppCompatActivity() {

    private lateinit var etNombre: EditText
    private lateinit var etEmail: EditText
    private lateinit var etPassword: EditText
    private lateinit var btnCrear: Button

    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin)

        // Fondo animado
        val rootLayout = findViewById<RelativeLayout>(R.id.rootLayoutAdmin)
        val animationDrawable = rootLayout.background as AnimationDrawable
        animationDrawable.setEnterFadeDuration(2000)
        animationDrawable.setExitFadeDuration(4000)
        animationDrawable.start()

        // Referencias UI
        etNombre = findViewById(R.id.etDocenteNombre)
        etEmail = findViewById(R.id.etDocenteEmail)
        etPassword = findViewById(R.id.etDocentePassword)
        btnCrear = findViewById(R.id.btnCrearDocente)

        // Botón de logout
        val btnLogout = findViewById<Button>(R.id.btnLogoutAdmin)
        btnLogout.setOnClickListener {
            FirebaseAuth.getInstance().signOut()
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }

        // Crear docente
        btnCrear.setOnClickListener {
            val nombre = etNombre.text.toString().trim()
            val email = etEmail.text.toString().trim()
            val password = etPassword.text.toString().trim()
            val creador = auth.currentUser?.uid ?: ""

            if (nombre.isEmpty() || email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Completa todos los campos", Toast.LENGTH_SHORT).show()
            } else {
                crearDocente(nombre, email, password, creador)
            }
        }
    }

    private fun crearDocente(nombre: String, email: String, password: String, creadoPor: String) {
        auth.createUserWithEmailAndPassword(email, password)
            .addOnSuccessListener { result ->
                val uid = result.user?.uid ?: return@addOnSuccessListener

                val docenteData = mapOf(
                    "nombre" to nombre,
                    "email" to email,
                    "rol" to "docente",
                    "creadoPor" to creadoPor
                )

                db.collection("users").document(uid).set(docenteData)
                    .addOnSuccessListener {
                        Toast.makeText(this, "Docente creado con éxito ✅", Toast.LENGTH_SHORT).show()
                        etNombre.text.clear()
                        etEmail.text.clear()
                        etPassword.text.clear()
                    }
                    .addOnFailureListener {
                        Toast.makeText(this, "Error al guardar en Firestore: ${it.message}", Toast.LENGTH_LONG).show()
                    }
            }
            .addOnFailureListener {
                Toast.makeText(this, "Error en Auth: ${it.message}", Toast.LENGTH_LONG).show()
            }
    }
}
