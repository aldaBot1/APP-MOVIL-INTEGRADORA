package com.example.loginappmovil

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.firestore.FirebaseFirestore
import com.squareup.picasso.Picasso

class AgregarLibroActivity : AppCompatActivity() {

    private lateinit var db: FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_agregar_libro)

        db = FirebaseFirestore.getInstance()

        val imgLibro = findViewById<ImageView>(R.id.imgLibroAgregar)
        val etTitulo = findViewById<EditText>(R.id.etTitulo)
        val etAutor = findViewById<EditText>(R.id.etAutor)
        val etDescripcion = findViewById<EditText>(R.id.etDescripcion)
        val btnGuardar = findViewById<Button>(R.id.btnGuardarLibro)

        // Recuperar datos que vienen desde LibrosActivity
        val titulo = intent.getStringExtra("titulo")
        val autor = intent.getStringExtra("autor")
        val descripcion = intent.getStringExtra("descripcion")
        val portada = intent.getStringExtra("portada")

        etTitulo.setText(titulo)
        etAutor.setText(autor)
        etDescripcion.setText(descripcion)

        if (!portada.isNullOrEmpty()) {
            Picasso.get().load(portada).into(imgLibro)
        }

        btnGuardar.setOnClickListener {
            val nuevoLibro = hashMapOf(
                "titulo" to etTitulo.text.toString(),
                "autor" to etAutor.text.toString(),
                "descripcion" to etDescripcion.text.toString(),
                "portada" to portada,
                "estado" to "Disponible"
            )

            db.collection("libros")
                .add(nuevoLibro)
                .addOnSuccessListener {
                    Toast.makeText(this, "Libro agregado correctamente", Toast.LENGTH_SHORT).show()
                    finish()
                }
                .addOnFailureListener {
                    Toast.makeText(this, "Error al guardar: ${it.message}", Toast.LENGTH_LONG).show()
                }
        }
    }
}
