package com.example.loginappmovil

import android.content.Intent
import android.graphics.drawable.AnimationDrawable
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class HomeActivity : AppCompatActivity() {

    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        // Fondo animado
        val rootLayout = findViewById<RelativeLayout>(R.id.rootLayoutHome)
        val animationDrawable = rootLayout.background as AnimationDrawable
        animationDrawable.setEnterFadeDuration(2000)
        animationDrawable.setExitFadeDuration(4000)
        animationDrawable.start()

        val tvBienvenida = findViewById<TextView>(R.id.tvBienvenidaAlumno)
        val btnLogout = findViewById<Button>(R.id.btnLogoutAlumno)
        val btnLibros = findViewById<LinearLayout>(R.id.btnLibros)
        val btnDispositivos = findViewById<LinearLayout>(R.id.btnDispositivos)

        // Cargar nombre del usuario
        val uid = auth.currentUser?.uid
        if (uid != null) {
            db.collection("users").document(uid).get()
                .addOnSuccessListener { document ->
                    val nombre = document.getString("nombre") ?: "Usuario"
                    tvBienvenida.text = "Bienvenido, $nombre 👋"
                }
        }

        // Navegación
        btnLibros.setOnClickListener {
            startActivity(Intent(this, LibrosActivity::class.java))
        }

        btnDispositivos.setOnClickListener {
            startActivity(Intent(this, DispositivosActivity::class.java))
        }

        // Cerrar sesión
        btnLogout.setOnClickListener {
            FirebaseAuth.getInstance().signOut()
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }
}
