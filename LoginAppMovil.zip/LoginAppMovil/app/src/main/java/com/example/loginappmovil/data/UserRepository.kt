package com.example.loginappmovil.data

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

data class User(
    val nombre: String = "",
    val email: String = "",
    val rol: String = "",  // admin, docente, alumno
    val creadoPor: String = "" // UID del creador
)

class UserRepository {
    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()

    fun registrarUsuario(
        email: String,
        password: String,
        nombre: String,
        rol: String,
        creadoPor: String,
        onSuccess: () -> Unit,
        onError: (Exception) -> Unit
    ) {
        auth.createUserWithEmailAndPassword(email, password)
            .addOnSuccessListener { result ->
                val uid = result.user?.uid ?: return@addOnSuccessListener
                val usuario = User(nombre, email, rol, creadoPor)
                db.collection("users").document(uid).set(usuario)
                    .addOnSuccessListener { onSuccess() }
                    .addOnFailureListener { onError(it) }
            }
            .addOnFailureListener { onError(it) }
    }
}
