package com.example.loginappmovil.data

import com.google.firebase.firestore.FirebaseFirestore

data class Loan(
    val bookId: String = "",
    val usuarioId: String = "",
    val docenteId: String = "",
    val fechaPrestamo: String = "",
    val fechaDevolucion: String = "",
    val estado: String = "pendiente" // pendiente, aprobado, devuelto
)

class LoanRepository {
    private val db = FirebaseFirestore.getInstance()

    fun crearPrestamo(prestamo: Loan, onSuccess: () -> Unit, onError: (Exception) -> Unit) {
        val docRef = db.collection("loans").document()
        db.collection("loans").document(docRef.id).set(prestamo)
            .addOnSuccessListener { onSuccess() }
            .addOnFailureListener { onError(it) }
    }

    fun cambiarEstado(loanId: String, nuevoEstado: String) {
        db.collection("loans").document(loanId)
            .update("estado", nuevoEstado)
    }
}
