package com.example.loginappmovil

import android.app.AlertDialog
import android.graphics.drawable.AnimationDrawable
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.squareup.picasso.Picasso

class MiCatalogoActivity : AppCompatActivity() {

    private lateinit var db: FirebaseFirestore
    private lateinit var auth: FirebaseAuth
    private lateinit var contenedor: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_micatalogo)

        val rootLayout = findViewById<LinearLayout>(R.id.rootLayoutCatalogo)
        contenedor = findViewById(R.id.contenedorCatalogo)

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()

        // Fondo animado
        try {
            val anim = rootLayout.background as AnimationDrawable
            anim.setEnterFadeDuration(2000)
            anim.setExitFadeDuration(4000)
            anim.start()
        } catch (e: Exception) {
            e.printStackTrace()
        }

        cargarLibrosDocente()
    }

    private fun cargarLibrosDocente() {
        contenedor.removeAllViews()
        val uidDocente = auth.currentUser?.uid ?: return

        db.collection("libros")
            .whereEqualTo("propietario", uidDocente)
            .get()
            .addOnSuccessListener { result ->
                if (result.isEmpty) {
                    val vacio = TextView(this)
                    vacio.text = "No tienes libros registrados aún."
                    vacio.setTextColor(resources.getColor(android.R.color.white))
                    vacio.textSize = 18f
                    contenedor.addView(vacio)
                    return@addOnSuccessListener
                }

                for (doc in result) {
                    val data = doc.data
                    val titulo = data["titulo"] as? String ?: "Sin título"
                    val autor = data["autor"] as? String ?: "Autor desconocido"
                    val descripcion = data["descripcion"] as? String ?: "Sin descripción"
                    val portada = data["portada"] as? String
                    val estado = data["estado"] as? String ?: "Disponible"

                    val vista = layoutInflater.inflate(R.layout.item_micatalogo, contenedor, false)

                    val img = vista.findViewById<ImageView>(R.id.imgLibroCat)
                    val tvTitulo = vista.findViewById<TextView>(R.id.tvTituloCat)
                    val tvAutor = vista.findViewById<TextView>(R.id.tvAutorCat)
                    val tvDescripcion = vista.findViewById<TextView>(R.id.tvDescripcionCat)
                    val tvEstado = vista.findViewById<TextView>(R.id.tvEstadoCat)
                    val btnEditar = vista.findViewById<Button>(R.id.btnEditarCat)
                    val btnEliminar = vista.findViewById<Button>(R.id.btnEliminarCat)

                    tvTitulo.text = titulo
                    tvAutor.text = autor
                    tvDescripcion.text = descripcion
                    tvEstado.text = "Estado: $estado"

                    if (!portada.isNullOrEmpty()) {
                        Picasso.get().load(portada.replace("http://", "https://"))
                            .fit()
                            .centerCrop()
                            .into(img)
                    } else {
                        img.setImageResource(android.R.drawable.ic_menu_report_image)
                    }

                    // Editar estado
                    btnEditar.setOnClickListener {
                        val opciones = arrayOf("Disponible", "Prestado", "En reparación")
                        AlertDialog.Builder(this)
                            .setTitle("Cambiar estado")
                            .setItems(opciones) { _, which ->
                                val nuevoEstado = opciones[which]
                                db.collection("libros").document(doc.id)
                                    .update("estado", nuevoEstado)
                                    .addOnSuccessListener {
                                        Toast.makeText(this, "Estado actualizado", Toast.LENGTH_SHORT).show()
                                        cargarLibrosDocente()
                                    }
                            }
                            .show()
                    }

                    // Eliminar libro
                    btnEliminar.setOnClickListener {
                        AlertDialog.Builder(this)
                            .setTitle("Eliminar libro")
                            .setMessage("¿Deseas eliminar '$titulo'?")
                            .setPositiveButton("Sí") { _, _ ->
                                db.collection("libros").document(doc.id)
                                    .delete()
                                    .addOnSuccessListener {
                                        Toast.makeText(this, "Libro eliminado", Toast.LENGTH_SHORT).show()
                                        cargarLibrosDocente()
                                    }
                            }
                            .setNegativeButton("No", null)
                            .show()
                    }

                    contenedor.addView(vista)
                }
            }
            .addOnFailureListener {
                Toast.makeText(this, "Error al cargar el catálogo", Toast.LENGTH_SHORT).show()
            }
    }
}
