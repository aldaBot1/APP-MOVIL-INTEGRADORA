package com.example.loginappmovil

import android.content.Intent
import android.graphics.drawable.AnimationDrawable
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class DispositivosActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dispositivos)

        // Fondo animado
        val rootLayout = findViewById<LinearLayout>(R.id.rootLayoutDispositivos)
        try {
            val animationDrawable = rootLayout.background as AnimationDrawable
            animationDrawable.setEnterFadeDuration(2000)
            animationDrawable.setExitFadeDuration(4000)
            animationDrawable.start()
        } catch (e: Exception) {
            e.printStackTrace()
        }

        val btnBuscar = findViewById<ImageButton>(R.id.btnBuscarDispositivo)
        val etBuscar = findViewById<EditText>(R.id.etBuscarDispositivo)
        val contenedor = findViewById<LinearLayout>(R.id.contenedorDispositivos)

        val navHome = findViewById<LinearLayout>(R.id.navHome)
        val navLibros = findViewById<LinearLayout>(R.id.navLibros)
        val navDispositivos = findViewById<LinearLayout>(R.id.navDispositivos)

        btnBuscar.setOnClickListener {
            val texto = etBuscar.text.toString().trim()
            if (texto.isNotEmpty()) {
                Toast.makeText(this, "Buscando: $texto", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Ingresa un dispositivo a buscar", Toast.LENGTH_SHORT).show()
            }
        }

        // Navegación inferior
        navHome.setOnClickListener {
            startActivity(Intent(this, HomeActivity::class.java))
            finish()
        }

        navLibros.setOnClickListener {
            startActivity(Intent(this, LibrosActivity::class.java))
            finish()
        }

        // Ejemplo de dispositivos
        val dispositivos = listOf(
            "Tablet Samsung Galaxy Tab",
            "Laptop HP Pavilion",
            "Proyector Epson X200",
            "Arduino Nano",
            "Sensor de temperatura IoT"
        )

        for (dispositivo in dispositivos) {
            val textView = TextView(this)
            textView.text = "💻 $dispositivo"
            textView.textSize = 18f
            textView.setTextColor(resources.getColor(android.R.color.white))
            textView.setPadding(0, 10, 0, 10)
            contenedor.addView(textView)
        }
    }
}
