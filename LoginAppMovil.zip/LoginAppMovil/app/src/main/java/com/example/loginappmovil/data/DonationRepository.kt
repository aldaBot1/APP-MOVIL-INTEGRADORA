package com.example.loginappmovil.data

import com.google.firebase.firestore.FirebaseFirestore

data class Donation(
    val bookId: String = "",
    val donadoPor: String = "",
    val fecha: String = ""
)

class DonationRepository {
    private val db = FirebaseFirestore.getInstance()

    fun registrarDonacion(donacion: Donation, onSuccess: () -> Unit, onError: (Exception) -> Unit) {
        val docRef = db.collection("donations").document()
        db.collection("donations").document(docRef.id).set(donacion)
            .addOnSuccessListener { onSuccess() }
            .addOnFailureListener { onError(it) }
    }
}
